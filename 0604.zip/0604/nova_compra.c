// Ler o valor da compra e uma opção: 1- A vista ou 2 - a prazo
// Se opção a vista, perguntar: 1 - pix (10% de desconto) 2 - débito (5% de desconto)
// Se opção a prazo, perguntar: 2 parcelas (sem acréscimo) ou 3 parcelas (5% de acréscimo)
// Exibir todas as respostas
#include <stdio.h>
int main(){
    float compra, desconto, juros, parcela;
    int escolha;
    printf("Digite o valor da compra:\n");
    scanf("%f", &compra);
    printf("1 --> A vista\n2 --> Prazo\n");
    scanf("%d", &escolha);
    if(escolha == 1){
        printf("1 --> Pix (10 porcento de desconto)\n2 --> Debito (5 porcento de desconto)\n");
        scanf("%d", &escolha);
        if(escolha == 1){
            desconto = 10.0 / 100 * compra;
            compra = compra - desconto;
            printf("Desconto de %.2f\nValor da compra com desconto: %.2f\n", desconto, compra);
        }
        else if(escolha == 2){
            desconto = 5.0 / 100 * compra;
            compra = compra - desconto;
            printf("Desconto de %.2f\nValor da compra com desconto: %.2f\n", desconto, compra);
        }
        else {
            printf("Escolha invalida\n");
        }
    }
    else if (escolha == 2){
        printf("2 --> 2 Parcelas (Sem acrescimo)\n3 --> 3 Parcelas (5 porcento de acrescimo)\n");
        scanf("%d", &escolha);
        if(escolha == 2){
            parcela = compra / 2;
            printf("2 parcelas de %.2f\nTotal: %.2f\n", parcela, compra);
        }
        else if(escolha == 3){
            juros = 5.0 / 100 * compra;
            parcela = (compra + juros)/ 3;
            compra = compra + juros;
            printf("3 parcelas de %.2f, com acrescimo de %.2f\nTotal: %.2f\n", parcela, juros, compra);
        }
        else{
            printf("Escolha invalida\n");
        }
    }
    else{
        printf("Escolha invalida\n");
    }
    return 0;
}