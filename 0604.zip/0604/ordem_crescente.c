// Ler 2 valores e exibi-los em ordem crescente

#include <stdio.h>
int main(){
    float n1, n2;
    printf("Digite dois numeros:\n");
    scanf("%f%f", &n1, &n2);

    if(n1 < n2){
        printf("%.2f, %.2f", n1, n2);
    }
    else{
        printf("%.2f, %.2f", n2, n1);
    }
    return 0;
}