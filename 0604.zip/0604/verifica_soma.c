// Ler 3 numeros positivos, verificar se o maior que a soma dos outros 2

#include <stdio.h>
int main(){
    float n1, n2, n3, soma, maior;

    printf("Digite tres numeros positivos:\n");
    scanf("%f%f%f", &n1, &n2, &n3);
   
    if(n1 > 0 && n2 > 0 && n3 > 0){
        if(n1 >= n2 && n1 >= n3){
            maior = n1;
            soma = n2 + n3;
            if(maior > soma){
                printf("%.2f maior que %.2f\n", maior, soma);
            }
            else{
                printf("%.2f menor que %.2f\n", maior, soma);
            }
        }
        else if(n2 >= n3){
            maior = n2;
            soma = n1 + n3;
            if(maior > soma){
                printf("%.2f maior que %.2f\n", maior, soma);
            }
            else{
                printf("%.2f menor que %.2f\n", maior, soma);
            }
        }
        else{
            maior = n3;
            soma = n1 + n2;
            if(maior > soma){
                printf("%.2f maior que %.2f\n", maior, soma);
            }
            else{
                printf("%.2f menor que %.2f\n", maior, soma);
            }
        }
    }
    else{
        printf("Numeros invalidos\n");
    }
    return 0;
}