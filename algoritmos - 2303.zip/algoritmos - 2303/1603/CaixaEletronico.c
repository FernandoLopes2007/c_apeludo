#include <stdio.h>

int main(){
    int Nota50, Nota20, Nota10, Resto, ValordeSaque;

    printf("Qual o valor do saque?\n");
    scanf("%d", &ValordeSaque);
    Nota50 = ValordeSaque / 50;
    Resto = ValordeSaque & 50;
    Nota20 = Resto / 20;
    Resto = Resto & 20;
    Nota10 = Resto / 10;
    printf("A quantidade de notas de 50: %d \n", Nota50);
    printf("A quantidade de notas de 20: %d \n", Nota20);
    printf("A quantidade de notas de 10: %d \n", Nota10);

    return 0;
}