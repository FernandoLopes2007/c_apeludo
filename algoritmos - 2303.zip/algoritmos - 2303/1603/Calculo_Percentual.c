//ler um valor e um percentual, calcular e exibir o percentual do valor
#include <stdio.h>
int main(){
    //declara variaveis
    float valor, percentual, resultado;
    //entrada de dados
    printf("digite o valor: ");
    scanf("%f", &valor);
    printf("digite o percentual: ");
    scanf("%f", &percentual);
    //processamento
    resultado = percentual / 100 * valor;
    //saida
    printf("%.2f%% de %.2f = %.2f\n", percentual, valor, resultado);
    return 0;
}