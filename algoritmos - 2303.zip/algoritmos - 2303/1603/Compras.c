//ler o valor da compra  e o percentual de desconto
//calcular e exibir o desconto e o valor final da compra
#include <stdio.h>
int main(){

    //declaraçao
    float valor_compra, percentual_desconto, valor_desconto, valor_final;
    //entrada
    printf("digite o valor da compra e o percentual de desconto:\n");
    scanf("%f%f",&valor_compra, &percentual_desconto);
    //processamento
    valor_desconto = percentual_desconto * valor_compra / 100;
    valor_final = valor_compra - valor_desconto;
    //saida
    printf("voce ganhou %.2f de desconto\n",valor_desconto);
    printf("valor final a pagar: %.2f\n",valor_final);
    return 0;
}