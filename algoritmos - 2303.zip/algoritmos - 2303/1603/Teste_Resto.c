//ler dois numeros inteiros, calcular e mostrar o reto da divisao do primeiro pelo segundo.
#include <stdio.h>
int main(){
    //declarar variaveis
    int numero1, numero2, resto;
    //entrada de dados
    printf("Digite o primeiro numero: ");
    scanf("%d", &numero1);
    printf("Digite o segundo numero: ");
    scanf("%d", &numero2);
    //processamento
    resto = numero1 % numero2;
    //saida
    printf("O resto de %d por %d e %d\n",numero1, numero2,resto);


    return 0;
}