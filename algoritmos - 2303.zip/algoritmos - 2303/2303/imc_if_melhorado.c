// Ler a altura (em m) e o peso (em kg)
// Calcular e mostrar o imc = peso / (altura ^ 2);

#include <stdio.h>
int main(){
    float peso, altura, imc; // Declaracao de variaveis
    printf("Digite seu peso:\n");
    scanf("%f", &peso); // Entrada de dados
    printf("Digite sua altura:\n");
    scanf("%f", &altura);
    imc = peso / (altura * altura); // Processamento de dados
    printf("Seu imc eh: %f\n", imc); // Saída de dados

    // Classificações do IMC
    if(imc <= 18.5){
        printf("Abaixo do peso normal.");
    } else if(imc >=18.5 && imc <= 24.9){
        printf("Peso normal.");
    } else if(imc >= 25.0 && imc <= 29.9){
        printf("Excesso de peso.");
    } else if(imc >= 30.0 && imc <= 34.9){
        printf("Obesidade classe 1.");
    } else if(imc >= 35.0 && imc <= 39.9){
        printf("Obesidade classe 2.");
    } else if(imc >= 40.0){
        printf("Obesidade classe 3.");
    }
    return 0;
}