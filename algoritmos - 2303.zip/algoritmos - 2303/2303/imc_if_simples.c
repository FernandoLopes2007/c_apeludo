// Ler a altura (em m) e o peso (em kg)
// Calcular e mostrar o imc = peso / (altura ^ 2);
// Mostrar se está acima do peso (imc > 25)

#include <stdio.h>
int main(){
    float peso, altura, imc; // Declaracao de variaveis
    printf("Digite seu peso:\n");
    scanf("%.2f", &peso); // Entrada de dados
    printf("Digite sua altura:\n");
    scanf("%.2f", &altura);
    imc = peso / (altura * altura); // Processamento de dados
    printf("Seu imc eh: %f\n", imc); // Saída de dados

    // Classificações do IMC
    if(imc > 25.0){
        printf("Acima do peso.");
    } 
    return 0;
}