//Ler um número e dizer se ele é ou não maior que 7
#include <stdio.h>

int main(){
    float numero;

    printf("Digite um numero:\n");
    scanf("%f", &numero);

    if(numero > 7){
        printf("%.2f e maior do que 7.", numero);
    }else{
        printf("%.2f e menor do que 7", numero);
    }

    return 0;
}
