//Ler 2 notas, calcular e exibir a média; se média >= 6.0, exibir aprovado
//Se não exibir reprovado
#include <stdio.h>

int main(){
    float nota1, nota2, media;

    printf("Digite a primeira nota, e depois a segunda:\n");
    scanf("%f%f", &nota1, &nota2);
    media = (nota1 + nota2) / 2;

    if(media >=6){
        printf("Aprovado com a media %.2f", media);
    }else{
        printf("Reprovado com a media %.2f", media);
    }

    return 0;
}