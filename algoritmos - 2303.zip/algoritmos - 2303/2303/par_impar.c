//Ler um número inteiro e verificar se ele e par ou impar

#include <stdio.h>

int main(){
    int numero;

    printf("Digite um numero:\n");
    scanf("%d", &numero);

    int resto = numero % 2;
    if(resto == 0){
        printf("%d e par\n", numero);
    }else {
        printf("%d e impart", numero );
    }

    return 0;
}