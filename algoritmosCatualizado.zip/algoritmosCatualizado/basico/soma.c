#include <stdio.h>
int main(){
    float a, b, resultado; // Criacao de variaveis
    printf("Digite um numero:\n");
    scanf("%f", &a); //entrada de dados
    printf("Digite outro numero:\n");
    scanf("%f", &b);
    resultado = a+b; //processamento de dados
    printf("Resultado da soma: %f", resultado); // saida de dados
    return 0;
}