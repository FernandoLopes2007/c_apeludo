#include <stdio.h>
int main(){
    float a, b, c, soma, multiplicacao;
    printf("Digite dois numeros para uma soma:\n");
    scanf("%f%f", &a, &b);
    soma = a+b;
    printf("Digite um numero para multiplicar a soma dos dois primeiros:\n");
    scanf("%f", &c);
    multiplicacao = soma * c;
    printf("Soma dos dois primeiros numeros: %.2f\nMultiplicacao apos a soma: %.2f", soma, multiplicacao);

    return 0;
}