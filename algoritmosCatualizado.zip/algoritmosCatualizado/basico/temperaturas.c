// Ler um temperatura em graus Celsius e transformar para 
// Fahrenheit: F = 9/5 * C + 32
#include <stdio.h>
int main(){
    float c, f;
    printf("Digite uma temperatura em Celsius:\n");
    scanf("%f", &c);
    f = c * 9/5 + 32;
    printf("Temperatura em Celsius: %2.f\nTemperatura em Fahrenheit: %.2f", c, f);

    return 0;
}