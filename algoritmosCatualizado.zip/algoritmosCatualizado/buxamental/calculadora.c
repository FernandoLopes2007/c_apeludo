#include <stdio.h>

int main (){
    char escolha;
    float a, b, resultado;
    printf("-- Super-Calculadora --\nEscolha a forma de calcular\n1-Soma\n2-Subtracao\n3-Multiplicacao\n4-Divisao\n");
    scanf("%c", &escolha);
    switch(escolha){
        case '1': 
            printf("-- SOMA --\n");
            printf("Digite um numero:\n");
            scanf("%f", &a);
            printf("Digite outro numero:\n");
            scanf("%f", &b);
            resultado = a+b;
            printf("Resultado %f", resultado);
        break;
        case '2':
            printf("-- SUBTRACAO --\n");
            printf("Digite um numero:\n");
            scanf("%f", &a);
            printf("Digite outro numero:\n");
            scanf("%f", &b);
            resultado = a-b;
            printf("Resultado %f", resultado);
        break;
        case'3':
            printf("-- MULTIPLICACAO --\n");
             printf("Digite um numero:\n");
            scanf("%f", &a);
            printf("Digite outro numero:\n");
            scanf("%f", &b);
            resultado = a*b;
            printf("Resultado %f", resultado);
        break;
        case'4':
            printf("-- DIVISAO --\n");
             printf("Digite um numero:\n");
            scanf("%f", &a);
            printf("Digite outro numero:\n");
            scanf("%f", &b);
            resultado = a/b;
            printf("Resultado %f", resultado);
        break;
        
        default:
            printf("Escolha incorreta, digite um valor valido\n");
        break;
    }  
    return 0;
}