#include <stdio.h>

void adicao(float n1, float n2){
    printf("--Adicao--\nDigite dois numeros:\n");
    scanf("%f%f", &n1, &n2);
    float adicao = n1 + n2;
    printf("Resultado: %.2f", adicao);
}
void subtracao(float n1, float n2){
    printf("--Subtracao--\nDigite dois numeros:\n");
    scanf("%f%f", &n1, &n2);
    float subtracao = n1 - n2;
    printf("Resultado: %.2f", subtracao);
}
void multiplicacao(float n1, float n2){
    printf("--Multiplicacao--\nDigite dois numeros:\n");
    scanf("%f%f", &n1, &n2);
    float multiplicacao = n1 * n2;
    printf("Resultado: %.2f", multiplicacao);
}
void divisao(float n1, float n2){
    printf("--Divisao--\nDigite dois numeros:\n");
    scanf("%f%f", &n1, &n2);
    float divisao = n1 / n2;
    printf("Resultado: %.2f", divisao);
}

