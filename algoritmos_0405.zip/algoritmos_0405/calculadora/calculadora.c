#include <stdio.h>
#include "biblioteca.h"
int main(){
    char escolha = ' ';
    float n1, n2, resultado;
    printf("Bem vindo a SuperCalculadora\n");
    while(escolha != 'q'){
        printf("\nEscolha a forma de calculo\n(1-Adicao 2-Subtracao 3-Multiplicacao 4-Divisao q-Sair)\n");
        scanf(" %c", &escolha);
        switch(escolha){
            case '1':
                adicao(n1, n2);
            break;
            case '2':
                subtracao(n1, n2);
            break;
            case '3':
                multiplicacao(n1 , n2);
            break;
            case '4':
                divisao(n1, n2);
            break;
            case 'q':
                printf("Saindo...");
            break;
            default:
            printf("Escolha incorreta\n");
        }
    }
    return 0;
}