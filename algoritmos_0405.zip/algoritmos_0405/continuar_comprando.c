//Escolher produtos e quantidades, mostrar o valor a pagar
//E perguntar se quer continuar comprando ou finalizar
#include <stdio.h>
int main(){
    int quantidade, produto;
    float valor_pagar = 0;
    char continua = 'c';
    while(continua == 'c'){
        printf("\nEscolha o produto:\n1- Lampada LED (R$ 0,50)\n2- Capacitor (R$ 1,00)\n3- Placa (R$ 5,00)\n--> ");
        scanf("%d", &produto);
        while(produto != 1 && produto != 2 && produto != 3){
            printf("\nProduto invalido!!!\nEscolha 1, 2 ou 3:\n--> ");
            scanf("%d", &produto);
        }
        printf("\nDigite a quantidade:\n-->");
        scanf("%d", &quantidade);
        if(produto == 1){
            valor_pagar = valor_pagar + 0.50 * quantidade;
        }else if(produto == 2){
            valor_pagar = valor_pagar + 1.00 * quantidade;
        }else if (produto == 3){
            valor_pagar = valor_pagar + 5.00 * quantidade;
        }
        printf("c- continuar f- finalizar\n--> ");
        scanf(" %c", &continua);
        while(continua != 'c' && continua != 'f'){
            printf("Escolha invalida!!!\nEscolha c ou f:\n--> ");
            scanf(" %c", &continua);
        }
    }
    printf("Total da compra = R$ %.2f\n", valor_pagar);
    return 0;
}