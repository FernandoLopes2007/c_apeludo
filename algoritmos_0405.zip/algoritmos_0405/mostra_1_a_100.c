#include <stdio.h>
int main(){
    int contador = 1;
    while(contador <=100){
        printf("%d ", contador);
        contador = contador + 1;
    }
    return 0;
}