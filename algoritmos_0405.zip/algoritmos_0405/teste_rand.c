#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(){
    char continua = 'c';
    while(continua == 'c'){
        unsigned long tempo = time(0);
        printf("tempo = %lu\n", tempo);
        srand(time(0));
        int m = rand();
        printf("m = %d\n", m);

        printf("c- continuar f- finalizar\n--> ");
        scanf(" %c", &continua);
        while(continua != 'c' && continua != 'f'){
            printf("Escolha invalida!!!\nEscolha c ou f:\n--> ");
            scanf(" %c", &continua);
        }
    }
    return 0;
}