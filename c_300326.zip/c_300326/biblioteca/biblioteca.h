#include <stdio.h>

void soma(float n1, float n2){
    float soma = n1 + n2;
    printf("Soma: %.2f", soma);
}

void subtracao(float n1, float n2){
    float subtracao = n1 - n2;
    printf("Subtracao: %.2f", subtracao);
}

void multiplicacao(float n1, float n2){
    float multiplicacao = n1 * n2;
    printf("Multiplicacao: %.2f", multiplicacao);
   
}

void divisao(float n1, float n2){
    float divisao = n1 / n2;
    printf("Divisao: %.2f", divisao);
}

