#include <stdio.h>
#include "biblioteca.h"

int main(){
    float n1, n2;
    int escolha;

    printf("--- CALCULADORA EM C ---\n\n");
    
    printf("Digite dois numeros:\n");
    scanf("%f%f", &n1, &n2);

    printf("O que quer fazer?\n1- Soma\n2- Subtracao\n3- Multiplicacao\n4- Divisao\n\n");
    scanf("%d", &escolha);
    switch(escolha){
        case 1:
            soma(n1, n2);
        break;
        case 2:
            subtracao(n1, n2);
        break;
        case 3:
            multiplicacao(n1, n2);
        break;
        case 4:
            divisao(n1, n2);
        break;
        default:
            printf("Escolha invalida\n");
        break;
    }
}
