// Ler um número e dizer se ele é positivo, negativo ou neutro
#include <stdio.h>

int main(){
    int n1;

    printf("Digite um numero:\n");
    scanf("%d", &n1);

    if(n1 < 0){
        printf("O numero %d e negativo\n", n1);
    }
    else if(n1 == 0){
        printf("O numero %d e neutro\n", n1);
    }
    else{
        printf("O numero %d e positivo\n", n1);
    }
}