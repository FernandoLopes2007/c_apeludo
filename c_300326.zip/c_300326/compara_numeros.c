//Ler 2 números quaisquer, dizer se são iguais, se o primeiro é o maior ou se o segundo é o maior
#include <stdio.h>

int main (){
    float n1, n2;
    
    printf("Digite um numero:\n");
    scanf("%f", &n1);
    printf("Digite outro numero:\n");
    scanf("%f", &n2);

    if(n1 == n2){
        printf("Os numeros %.2f e %.2f sao iguais\n", n1, n2);
    }else if(n1 > n2){
        printf("O numero %.2f e maior que %.2f\n", n1, n2);
    }else{
        printf("O numero %.2f e menor que %.2f\n", n1, n2);
    }

    return 0;
}