// Ler o valor de uma compra e o numero de parcelas (2, 3, 4).
// Calcular e mostrar o valor de cada parcela. Para outros valores, exibir mensagem de erro
// Para 3 parcelas calcular juros de 10% e 4 parcelas, 20%
#include <stdio.h>

int main(){
    float valor_compra, valor_parcelado, juros;
    int qtd_parcelas;

    printf("Digite o valor da compra:\n");
    scanf("%f", &valor_compra);
    printf("Digite a quantidade de parcelas (maximo 4 vezes)\n");
    scanf("%d", &qtd_parcelas);

    if(qtd_parcelas == 1){
        printf("Valor da parcela: %.2f\n", valor_compra);
    }
    else if(qtd_parcelas == 2){
        valor_parcelado = valor_compra / 2;
        printf("Valor da parcela: %.2f\n", valor_parcelado);
    }
    else if(qtd_parcelas == 3){
        juros = 10.0 / 100 * valor_compra;
        valor_parcelado = (valor_compra + juros) / 3;
        printf("Acrescimo de %.2f\n", juros);
        printf("Valor da parcela: %.2f\n", valor_parcelado);
    }
    else if(qtd_parcelas == 4){
        juros = 20.0 /100 * valor_compra;
        valor_parcelado = (valor_compra + juros)/ 4;
        printf("Acrescimo de %.2f\n", juros);
        printf("Valor da parcela: %.2f\n", valor_parcelado);
    }
    else{
        printf("Quantidade de parcelas invaldio!!");
    }
    
    return 0;
}